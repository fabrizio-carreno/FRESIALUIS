import { useEffect, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Menu, X } from 'lucide-react';
import { nav, site } from '../../data/site.js';
import useActiveSection from '../../hooks/useActiveSection.js';
import Button from '../ui/Button.jsx';

export default function Header() {
  const [open, setOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const active = useActiveSection(nav.map((n) => n.id));

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 16);
    onScroll();
    window.addEventListener('scroll', onScroll, { passive: true });
    return () => window.removeEventListener('scroll', onScroll);
  }, []);

  useEffect(() => {
    const onKey = (e) => e.key === 'Escape' && setOpen(false);
    document.addEventListener('keydown', onKey);
    return () => document.removeEventListener('keydown', onKey);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-[80] transition-all duration-500 ${
        scrolled || open ? 'bg-crema/90 shadow-card backdrop-blur-md' : 'bg-transparent'
      }`}
    >
      <div className="container-x flex h-[72px] items-center justify-between">
        <a href="#inicio" className="flex items-center gap-2" aria-label={`${site.name} · Inicio`}>
          <span className="grid h-9 w-9 place-items-center rounded-full bg-fucsia text-white">
            <span className="font-display text-lg font-bold">F</span>
          </span>
          <span className="font-display text-xl font-bold tracking-tight">{site.name}</span>
        </a>

        <nav aria-label="Principal" className="hidden items-center gap-1 lg:flex">
          {nav.map((item) => (
            <a
              key={item.id}
              href={`#${item.id}`}
              aria-current={active === item.id ? 'page' : undefined}
              className="group relative px-3 py-2 text-sm font-semibold text-marino/80 transition-colors hover:text-fucsia"
            >
              {item.label}
              <span
                className={`absolute inset-x-3 -bottom-0.5 h-0.5 origin-left rounded bg-fucsia transition-transform duration-300 ${
                  active === item.id ? 'scale-x-100' : 'scale-x-0 group-hover:scale-x-100'
                }`}
              />
            </a>
          ))}
          <Button href="#reservar" className="ml-3 !px-5 !py-2.5">Reservar una cita</Button>
        </nav>

        <button
          className="grid h-11 w-11 place-items-center rounded-full bg-white text-marino shadow-card lg:hidden"
          aria-label={open ? 'Cerrar menú' : 'Abrir menú'}
          aria-expanded={open}
          aria-controls="menu-movil"
          onClick={() => setOpen((v) => !v)}
        >
          {open ? <X size={22} aria-hidden="true" /> : <Menu size={22} aria-hidden="true" />}
        </button>
      </div>

      <AnimatePresence>
        {open && (
          <motion.nav
            id="menu-movil"
            aria-label="Principal móvil"
            className="overflow-hidden lg:hidden"
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
          >
            <ul className="container-x flex flex-col gap-1 pb-6">
              {nav.map((item, i) => (
                <motion.li key={item.id} initial={{ opacity: 0, x: -12 }} animate={{ opacity: 1, x: 0 }} transition={{ delay: 0.04 * i }}>
                  <a
                    href={`#${item.id}`}
                    onClick={() => setOpen(false)}
                    className="block rounded-xl px-4 py-3 text-lg font-semibold hover:bg-fucsia-soft hover:text-fucsia"
                  >
                    {item.label}
                  </a>
                </motion.li>
              ))}
              <li className="pt-3">
                <Button href="#reservar" onClick={() => setOpen(false)} className="w-full">Reservar una cita</Button>
              </li>
            </ul>
          </motion.nav>
        )}
      </AnimatePresence>
    </header>
  );
}
