import { Instagram, MessageCircle, Mail, MapPin } from 'lucide-react';
import { nav, site } from '../../data/site.js';
import { services } from '../../data/content.js';

const wa = () => {
  const n = site.contact.whatsappNumber.replace(/\D/g, '');
  return n ? `https://wa.me/${n}` : null;
};

export default function Footer() {
  const { contact, legal } = site;
  const waUrl = wa();
  const socials = [
    contact.instagramUrl && { href: contact.instagramUrl, label: 'Instagram', Icon: Instagram },
    waUrl && { href: waUrl, label: 'WhatsApp', Icon: MessageCircle },
  ].filter(Boolean);

  return (
    <footer id="contacto" className="relative overflow-hidden bg-marino text-white">
      <div className="container-x grid gap-12 py-16 md:grid-cols-2 lg:grid-cols-4">
        <div>
          <p className="font-display text-3xl font-bold">{site.name}</p>
          <p className="mt-1 font-script text-2xl text-sol">{site.role}</p>
          <p className="mt-4 max-w-xs text-sm leading-relaxed text-white/70">{site.tagline}</p>
        </div>

        <div>
          <h3 className="font-sans text-sm font-bold uppercase tracking-wider !text-white/50">Navegación</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {nav.map((n) => (
              <li key={n.id}><a className="text-white/80 transition hover:text-sol" href={`#${n.id}`}>{n.label}</a></li>
            ))}
          </ul>
        </div>

        <div>
          <h3 className="font-sans text-sm font-bold uppercase tracking-wider !text-white/50">Servicios</h3>
          <ul className="mt-4 space-y-2 text-sm">
            {services.map((s) => (
              <li key={s.id}><a className="text-white/80 transition hover:text-sol" href="#servicios">{s.name}</a></li>
            ))}
            <li><a className="text-white/80 transition hover:text-sol" href="#agendas">Agenda Volver a mí</a></li>
          </ul>
        </div>

        <div>
          <h3 className="font-sans text-sm font-bold uppercase tracking-wider !text-white/50">Contacto</h3>
          <ul className="mt-4 space-y-3 text-sm text-white/80">
            {contact.email && (
              <li className="flex items-center gap-2"><Mail size={16} aria-hidden="true" /><a className="hover:text-sol" href={`mailto:${contact.email}`}>{contact.email}</a></li>
            )}
            {contact.location && <li className="flex items-center gap-2"><MapPin size={16} aria-hidden="true" />{contact.location}</li>}
            {!contact.email && !contact.location && !waUrl && (
              <li className="text-white/50">Datos de contacto por configurar en <code>src/data/site.js</code>.</li>
            )}
          </ul>
          {socials.length > 0 && (
            <div className="mt-5 flex gap-3">
              {socials.map(({ href, label, Icon }) => (
                <a key={label} href={href} target="_blank" rel="noopener noreferrer" aria-label={label}
                  className="grid h-11 w-11 place-items-center rounded-full bg-white/10 transition hover:bg-fucsia">
                  <Icon size={20} aria-hidden="true" />
                </a>
              ))}
            </div>
          )}
        </div>
      </div>

      <div className="border-t border-white/10">
        <div className="container-x flex flex-col items-center justify-between gap-3 py-6 text-xs text-white/60 sm:flex-row">
          <p>© {new Date().getFullYear()} {site.name}. Todos los derechos reservados.</p>
          <p className="max-w-md text-center sm:text-right">
            Contenido informativo. Esta web no ofrece diagnósticos ni atención de emergencias.{' '}
            <a className="underline hover:text-sol" href={legal.privacyUrl}>Privacidad</a> ·{' '}
            <a className="underline hover:text-sol" href={legal.termsUrl}>Términos</a>
          </p>
        </div>
      </div>
    </footer>
  );
}
