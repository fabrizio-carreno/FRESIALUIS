import { MessageCircle } from 'lucide-react';
import { site } from '../../data/site.js';

/** Botón flotante de WhatsApp. Se oculta hasta que configures el número en data/site.js. */
export default function FloatingWhatsApp() {
  const n = site.contact.whatsappNumber.replace(/\D/g, '');
  if (!n) return null;
  return (
    <a
      href={`https://wa.me/${n}?text=${encodeURIComponent('Hola Fresia, quisiera más información.')}`}
      target="_blank"
      rel="noopener noreferrer"
      aria-label="Escribir por WhatsApp"
      className="fixed bottom-5 right-5 z-[70] grid h-14 w-14 place-items-center rounded-full bg-turquesa text-white shadow-lift transition hover:scale-110 hover:bg-turquesa-dark"
    >
      <MessageCircle size={26} aria-hidden="true" />
    </a>
  );
}
