import { useCallback, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ChevronLeft, ChevronRight, Play, ZoomIn, ZoomOut } from 'lucide-react';
import { gallery } from '../../data/content.js';
import SectionHeading from '../ui/SectionHeading.jsx';
import Modal from '../ui/Modal.jsx';
import DemoBadge from '../ui/DemoBadge.jsx';
import Flower from '../ui/Flower.jsx';

const thumb = (item) => (item.type === 'image' ? item.src : item.poster);
const total = gallery.length;
// Distancia circular con signo (-n/2 … n/2) entre la tarjeta i y la activa
const offsetOf = (i, active) => {
  let d = i - active;
  if (d > total / 2) d -= total;
  if (d < -total / 2) d += total;
  return d;
};

export default function MediaGallery() {
  const [active, setActive] = useState(0);
  const [open, setOpen] = useState(null); // índice abierto en el modal
  const [zoom, setZoom] = useState(false);

  const go = useCallback((dir) => setActive((a) => (a + dir + total) % total), []);
  const goModal = (dir) => { setZoom(false); setOpen((o) => (o + dir + total) % total); };
  const current = open !== null ? gallery[open] : null;

  const onKeyDown = (e) => {
    if (e.key === 'ArrowLeft') go(-1);
    if (e.key === 'ArrowRight') go(1);
  };

  return (
    <section id="galeria" className="section-y relative overflow-hidden bg-marino text-white">
      <div aria-hidden="true" className="absolute -left-24 top-10 w-72 opacity-20"><Flower palette="warm" spin /></div>
      <div aria-hidden="true" className="absolute -right-24 bottom-10 w-80 opacity-20"><Flower palette="cool" spin /></div>

      <div className="container-x relative">
        <div className="[&_h2]:!text-white [&_p:last-child]:!text-white/70 [&_.eyebrow]:!text-sol">
          <SectionHeading
            eyebrow="Fotos y videos"
            title="Momentos, ideas y bienestar"
            text="Fotografías, videos educativos y fragmentos de actividades y proyectos."
          />
        </div>

        {/* Carrusel tipo coverflow */}
        <div
          role="group" aria-roledescription="carrusel" aria-label="Galería de fotos y videos" tabIndex={0} onKeyDown={onKeyDown}
          className="relative mx-auto h-[440px] max-w-5xl outline-none sm:h-[560px]"
        >
          <motion.div
            className="absolute inset-0 cursor-grab touch-pan-y active:cursor-grabbing"
            drag="x" dragConstraints={{ left: 0, right: 0 }} dragElastic={0.2}
            onDragEnd={(_, info) => {
              if (info.offset.x < -60) go(1);
              else if (info.offset.x > 60) go(-1);
            }}
          >
            {gallery.map((item, i) => {
              const off = offsetOf(i, active);
              const abs = Math.abs(off);
              const visible = abs <= 2;
              return (
                <motion.button
                  key={item.id}
                  type="button"
                  aria-label={`${item.title}${item.type !== 'image' ? ' (video)' : ''}${off === 0 ? '. Abrir' : '. Ir a este elemento'}`}
                  aria-hidden={!visible}
                  tabIndex={visible ? 0 : -1}
                  onClick={() => (off === 0 ? (setZoom(false), setOpen(i)) : setActive(i))}
                  className="absolute left-1/2 top-1/2 aspect-[3/4] w-[240px] overflow-hidden rounded-3xl border-4 border-white/90 bg-white text-left shadow-2xl sm:w-[340px]"
                  initial={false}
                  animate={{
                    x: `calc(-50% + ${off * 52}%)`, y: '-50%',
                    scale: 1 - abs * 0.14, opacity: visible ? 1 - abs * 0.3 : 0,
                    zIndex: 10 - abs, rotate: off * 3,
                  }}
                  transition={{ type: 'spring', stiffness: 220, damping: 26 }}
                  style={{ pointerEvents: visible ? 'auto' : 'none' }}
                >
                  <img src={thumb(item)} alt={item.alt} loading="lazy" draggable="false" className="h-full w-full object-cover" />
                  <div className="absolute inset-x-0 bottom-0 bg-gradient-to-t from-marino/85 to-transparent p-4 pt-16">
                    <p className="font-display text-lg font-bold leading-tight">{item.title}</p>
                    {item.caption && <p className="text-xs text-white/75">{item.caption}</p>}
                  </div>
                  {item.type !== 'image' && (
                    <span className="absolute left-1/2 top-1/2 grid h-16 w-16 -translate-x-1/2 -translate-y-1/2 place-items-center rounded-full bg-fucsia text-white shadow-lift">
                      <Play size={28} aria-hidden="true" className="translate-x-0.5" fill="currentColor" />
                    </span>
                  )}
                  {item.demo && <DemoBadge className="absolute left-3 top-3" />}
                </motion.button>
              );
            })}
          </motion.div>

          <button onClick={() => go(-1)} aria-label="Anterior" className="absolute left-0 top-1/2 z-20 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full bg-white text-marino shadow-lift transition hover:bg-fucsia hover:text-white sm:-left-4">
            <ChevronLeft aria-hidden="true" />
          </button>
          <button onClick={() => go(1)} aria-label="Siguiente" className="absolute right-0 top-1/2 z-20 grid h-12 w-12 -translate-y-1/2 place-items-center rounded-full bg-white text-marino shadow-lift transition hover:bg-fucsia hover:text-white sm:-right-4">
            <ChevronRight aria-hidden="true" />
          </button>
        </div>

        {/* Indicadores */}
        <div className="mt-8 flex flex-wrap items-center justify-center gap-2" role="tablist" aria-label="Elegir elemento">
          {gallery.map((item, i) => (
            <button key={item.id} role="tab" aria-selected={i === active} aria-label={item.title} onClick={() => setActive(i)}
              className={`h-2.5 rounded-full transition-all duration-300 ${i === active ? 'w-10 bg-sol' : 'w-2.5 bg-white/30 hover:bg-white/60'}`} />
          ))}
        </div>
        <p className="mt-4 text-center text-xs text-white/50" aria-live="polite">{active + 1} / {total} · Desliza, usa las flechas o toca para ampliar</p>
      </div>

      {/* Visor (foto con zoom o video) */}
      <Modal open={open !== null} onClose={() => { setOpen(null); setZoom(false); }} label={current?.title || 'Visor'} wide dark>
        {current && (
          <div>
            <div className="relative flex min-h-[50vh] items-center justify-center overflow-hidden bg-black">
              <AnimatePresence mode="wait">
                <motion.div key={current.id} className="flex w-full justify-center"
                  initial={{ opacity: 0, x: 30 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -30 }} transition={{ duration: 0.3 }}>
                  {current.type === 'image' && (
                    <motion.img src={current.src} alt={current.alt} onClick={() => setZoom((z) => !z)}
                      animate={{ scale: zoom ? 1.7 : 1 }} transition={{ type: 'spring', stiffness: 160, damping: 22 }}
                      className={`max-h-[75vh] w-auto object-contain ${zoom ? 'cursor-zoom-out' : 'cursor-zoom-in'}`} />
                  )}
                  {current.type === 'video' && current.src && (
                    <video src={current.src} poster={current.poster} controls playsInline className="max-h-[75vh] w-full" />
                  )}
                  {current.type === 'embed' && current.src && (
                    <iframe src={current.src} title={current.title} allow="accelerometer; encrypted-media; picture-in-picture" allowFullScreen className="aspect-video w-full" />
                  )}
                  {current.type !== 'image' && !current.src && (
                    <div className="relative w-full max-w-xl p-6 text-center">
                      <img src={current.poster} alt="" className="mx-auto max-h-[45vh] rounded-2xl opacity-60" />
                      <div className="absolute inset-0 grid place-items-center p-8">
                        <div className="rounded-2xl bg-marino/90 p-6">
                          <DemoBadge />
                          <p className="mt-3 font-display text-xl font-bold">Aquí irá tu video</p>
                          <p className="mt-1 text-sm text-white/70">Añade el archivo en <code>public/media/videos/</code> y escribe su ruta en <code>src/data/content.js</code>.</p>
                        </div>
                      </div>
                    </div>
                  )}
                </motion.div>
              </AnimatePresence>
              <button onClick={() => goModal(-1)} aria-label="Anterior" className="absolute left-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-marino hover:bg-fucsia hover:text-white"><ChevronLeft aria-hidden="true" /></button>
              <button onClick={() => goModal(1)} aria-label="Siguiente" className="absolute right-3 top-1/2 grid h-11 w-11 -translate-y-1/2 place-items-center rounded-full bg-white/90 text-marino hover:bg-fucsia hover:text-white"><ChevronRight aria-hidden="true" /></button>
            </div>
            <div className="flex items-center justify-between gap-4 p-5">
              <div><p className="font-display text-xl font-bold">{current.title}</p>{current.caption && <p className="text-sm text-white/70">{current.caption}</p>}</div>
              {current.type === 'image' && (
                <button onClick={() => setZoom((z) => !z)} className="inline-flex items-center gap-2 rounded-full bg-white/10 px-4 py-2 text-sm font-semibold hover:bg-white/20">
                  {zoom ? <ZoomOut size={18} aria-hidden="true" /> : <ZoomIn size={18} aria-hidden="true" />}{zoom ? 'Alejar' : 'Ampliar'}
                </button>
              )}
            </div>
          </div>
        )}
      </Modal>
    </section>
  );
}
