import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, CalendarHeart } from 'lucide-react';
import { topics, topicsDisclaimer } from '../../data/content.js';
import { tones } from '../ui/tones.js';
import { Stagger, StaggerItem } from '../ui/Reveal.jsx';
import SectionHeading from '../ui/SectionHeading.jsx';
import Icon from '../ui/Icon.jsx';
import Modal from '../ui/Modal.jsx';
import Button from '../ui/Button.jsx';
import Flower from '../ui/Flower.jsx';

export default function Topics() {
  const [selected, setSelected] = useState(null);
  const t = selected && tones[selected.tone];

  return (
    <section id="psicologia" className="section-y relative">
      <div className="container-x">
        <SectionHeading
          eyebrow="Psicología y bienestar"
          title="Temas para conocerte mejor"
          text="Explora ideas para acompañar tu bienestar emocional y tu crecimiento personal."
        />

        <Stagger className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {topics.map((topic) => {
            const tone = tones[topic.tone];
            return (
              <StaggerItem key={topic.id}>
                <motion.article whileHover={{ y: -8 }} transition={{ type: 'spring', stiffness: 260, damping: 22 }}
                  className="group card relative flex h-full flex-col overflow-hidden p-7 transition-shadow duration-300 hover:shadow-lift">
                  {/* Ilustración: flor decorativa que crece al hover */}
                  <div aria-hidden="true" className={`absolute -right-10 -top-10 h-36 w-36 rounded-full ${tone.soft} transition-transform duration-500 group-hover:scale-125`} />
                  <div className="relative">
                    <span className={`grid h-14 w-14 place-items-center rounded-2xl ${tone.solid} shadow-card`}>
                      <Icon name={topic.icon} size={26} />
                    </span>
                    <h3 className="mt-5 text-2xl font-bold leading-tight">{topic.title}</h3>
                    <p className="mt-2 flex-1 text-sm leading-relaxed text-marino/70">{topic.short}</p>
                  </div>
                  <button onClick={() => setSelected(topic)} className={`relative mt-6 inline-flex items-center gap-1 self-start text-sm font-bold ${tone.text} hover:underline`}
                    aria-label={`Conocer más sobre ${topic.title}`}>
                    Conocer más <ArrowUpRight size={16} aria-hidden="true" className="transition-transform group-hover:-translate-y-0.5 group-hover:translate-x-0.5" />
                  </button>
                </motion.article>
              </StaggerItem>
            );
          })}
        </Stagger>
        <p className="mx-auto mt-10 max-w-xl text-center text-xs text-marino/50">{topicsDisclaimer}</p>
      </div>

      <Modal open={Boolean(selected)} onClose={() => setSelected(null)} label={selected?.title || 'Tema'}>
        {selected && (
          <article>
            <div className={`relative overflow-hidden px-8 pb-8 pt-12 ${t.soft}`}>
              <div className="absolute -right-8 -top-8 w-40 opacity-70"><Flower palette="warm" spin /></div>
              <span className={`relative grid h-14 w-14 place-items-center rounded-2xl ${t.solid}`}><Icon name={selected.icon} size={26} /></span>
              <h3 className="relative mt-4 text-3xl font-bold sm:text-4xl">{selected.title}</h3>
            </div>
            <div className="space-y-4 px-8 py-7 text-marino/80">
              {selected.detail.map((p, i) => <p key={i} className="leading-relaxed">{p}</p>)}
              <h4 className="pt-2 font-display text-xl font-bold text-marino">Ideas para empezar</h4>
              <ul className="grid gap-2 sm:grid-cols-3">
                {selected.ideas.map((idea) => <li key={idea} className={`rounded-2xl p-3 text-sm font-semibold ${t.soft}`}>{idea}</li>)}
              </ul>
              <p className="rounded-xl bg-crema p-3 text-xs text-marino/60">{topicsDisclaimer}</p>
              <Button href="#reservar" onClick={() => setSelected(null)}><CalendarHeart size={18} aria-hidden="true" /> Solicitar una cita</Button>
            </div>
          </article>
        )}
      </Modal>
    </section>
  );
}
