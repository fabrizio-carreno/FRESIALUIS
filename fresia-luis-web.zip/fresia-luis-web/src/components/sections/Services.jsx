import { useState } from 'react';
import { motion } from 'framer-motion';
import { CalendarHeart, Info, MapPin, Monitor } from 'lucide-react';
import { modalityLabels, services } from '../../data/content.js';
import { Stagger, StaggerItem } from '../ui/Reveal.jsx';
import SectionHeading from '../ui/SectionHeading.jsx';
import Icon from '../ui/Icon.jsx';
import Button from '../ui/Button.jsx';
import DemoBadge from '../ui/DemoBadge.jsx';
import Booking from '../booking/Booking.jsx';

const modalIcon = { virtual: Monitor, presencial: MapPin };

export default function Services() {
  const [serviceId, setServiceId] = useState(null);
  const choose = (id) => {
    setServiceId(id);
    document.getElementById('reservar')?.scrollIntoView({ behavior: 'smooth', block: 'start' });
  };

  return (
    <section id="servicios" className="section-y relative bg-white">
      <div className="container-x">
        <SectionHeading eyebrow="Servicios" title="Cómo puedo acompañarte" text="Elige el espacio que mejor se ajuste a lo que necesitas hoy." />

        <Stagger className="grid gap-6 md:grid-cols-3">
          {services.map((s) => (
            <StaggerItem key={s.id}>
              <motion.article whileHover={{ y: -6 }} className="card flex h-full flex-col border-b-4 border-fucsia p-7 transition-shadow hover:shadow-lift">
                <div className="flex items-start justify-between">
                  <span className="grid h-14 w-14 place-items-center rounded-2xl bg-fucsia-soft text-fucsia"><Icon name={s.icon} size={26} /></span>
                  {s.demo && <DemoBadge>Ejemplo</DemoBadge>}
                </div>
                <h3 className="mt-5 text-2xl font-bold">{s.name}</h3>
                <p className="mt-2 text-sm leading-relaxed text-marino/70">{s.description}</p>
                <ul className="mt-4 flex flex-wrap gap-2">
                  {s.modalities.map((m) => {
                    const M = modalIcon[m];
                    return <li key={m} className="inline-flex items-center gap-1.5 rounded-full bg-turquesa-soft px-3 py-1 text-xs font-bold text-turquesa-dark"><M size={14} aria-hidden="true" />{modalityLabels[m]}</li>;
                  })}
                </ul>
                <p className="mt-4 flex items-start gap-2 text-xs text-marino/55">
                  <Info size={14} className="mt-0.5 shrink-0" aria-hidden="true" />
                  {[s.duration && `Duración: ${s.duration}`, s.price && `Inversión: ${s.price}`].filter(Boolean).join(' · ') || 'Duración e inversión: consúltalas al solicitar tu cita.'}
                </p>
                <div className="mt-auto pt-6"><Button onClick={() => choose(s.id)} className="w-full"><CalendarHeart size={18} aria-hidden="true" /> Reservar</Button></div>
              </motion.article>
            </StaggerItem>
          ))}
        </Stagger>

        <div className="mt-20 rounded-[2.5rem] bg-crema p-4 sm:p-10">
          <Booking serviceId={serviceId} onServiceChange={setServiceId} />
          <p className="mx-auto mt-5 max-w-2xl text-center text-xs text-marino/55">
            Esta página no es un servicio de emergencias. Si estás en una situación de riesgo, comunícate de inmediato con los servicios de emergencia de tu localidad.
          </p>
        </div>
      </div>
    </section>
  );
}
