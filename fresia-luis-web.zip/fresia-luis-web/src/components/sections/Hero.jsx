import { useRef } from 'react';
import { motion, useScroll, useTransform } from 'framer-motion';
import { ArrowRight, CalendarHeart, Sparkles } from 'lucide-react';
import { photos } from '../../data/content.js';
import { site } from '../../data/site.js';
import Button from '../ui/Button.jsx';
import Flower from '../ui/Flower.jsx';

const ease = [0.22, 1, 0.36, 1];
const fadeUp = (delay) => ({
  initial: { opacity: 0, y: 30 },
  animate: { opacity: 1, y: 0 },
  transition: { duration: 0.8, delay, ease },
});

export default function Hero() {
  const ref = useRef(null);
  const { scrollYProgress } = useScroll({ target: ref, offset: ['start start', 'end start'] });
  const photoY = useTransform(scrollYProgress, [0, 1], ['0%', '8%']); // parallax sutil
  const flowerY = useTransform(scrollYProgress, [0, 1], ['0%', '-18%']);

  return (
    <section id="inicio" ref={ref} className="relative overflow-hidden pt-28 sm:pt-32 lg:pt-36">
      {/* Fondo orgánico */}
      <div aria-hidden="true" className="pointer-events-none absolute -right-40 top-10 h-[560px] w-[560px] animate-blob bg-rosa-soft" />
      <div aria-hidden="true" className="pointer-events-none absolute -left-32 bottom-0 h-72 w-72 rounded-full bg-sol-soft blur-2xl" />

      <div className="container-x relative grid items-center gap-10 pb-20 lg:grid-cols-[1.05fr_1fr] lg:gap-6 lg:pb-28">
        {/* Texto */}
        <div className="order-2 lg:order-1">
          <motion.p {...fadeUp(0.1)} className="eyebrow flex items-center gap-2">
            <Sparkles size={22} aria-hidden="true" /> {site.role}
          </motion.p>
          <motion.h1 {...fadeUp(0.2)} className="mt-2 text-6xl font-extrabold leading-[0.95] sm:text-7xl xl:text-8xl">
            {site.name}
          </motion.h1>
          <motion.p {...fadeUp(0.35)} className="mt-6 max-w-xl font-display text-2xl font-medium leading-snug text-fucsia sm:text-3xl">
            {site.tagline}
          </motion.p>
          <motion.p {...fadeUp(0.45)} className="mt-5 max-w-lg text-base leading-relaxed text-marino/75 sm:text-lg">
            {site.intro}
          </motion.p>
          <motion.div {...fadeUp(0.6)} className="mt-9 flex flex-wrap gap-3">
            <Button href="#sobre-mi" variant="outline">Conóceme <ArrowRight size={18} aria-hidden="true" className="transition-transform group-hover:translate-x-1" /></Button>
            <Button href="#reservar"><CalendarHeart size={18} aria-hidden="true" /> Reserva tu cita</Button>
          </motion.div>
        </div>

        {/* Fotografía protagonista */}
        <motion.div
          className="relative order-1 mx-auto w-full max-w-md lg:order-2 lg:max-w-lg"
          initial={{ opacity: 0, scale: 0.94 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 1, ease }}
        >
          <motion.div style={{ y: flowerY }} className="absolute -left-10 -top-8 z-0 w-36 sm:w-44">
            <Flower palette="warm" spin />
          </motion.div>
          <motion.div style={{ y: flowerY }} className="absolute -bottom-8 -right-6 z-20 w-24 sm:w-32">
            <Flower palette="cool" petals={8} spin />
          </motion.div>

          {/* Marco en arco */}
          <div className="relative z-10 overflow-hidden rounded-t-[999px] rounded-b-[2.5rem] border-[6px] border-white bg-fucsia-soft shadow-lift">
            <motion.img
              src={photos.hero.src}
              alt={photos.hero.alt}
              style={{ y: photoY, scale: 1.08 }}
              className="aspect-[3/4] w-full object-cover object-top"
              width="694"
              height="928"
            />
          </div>

          {/* Chips flotantes */}
          <div className="absolute -left-3 bottom-16 z-30 animate-floaty rounded-2xl bg-white px-4 py-3 shadow-card sm:-left-8">
            <p className="font-script text-xl leading-none text-fucsia">Agenda</p>
            <p className="text-sm font-bold">Volver a mí</p>
          </div>
          <div className="absolute -right-2 top-20 z-30 hidden animate-floaty rounded-2xl bg-sol px-4 py-3 shadow-card [animation-delay:1.5s] sm:block">
            <p className="text-sm font-bold">Psicología<br />&amp; bienestar</p>
          </div>
        </motion.div>
      </div>

      {/* Divisor ondulado hacia la siguiente sección */}
      <svg aria-hidden="true" viewBox="0 0 1440 60" preserveAspectRatio="none" className="block h-10 w-full text-white sm:h-14">
        <path fill="currentColor" d="M0 30c240 40 480 40 720 10s480-40 720 0v20H0z" />
      </svg>
    </section>
  );
}
