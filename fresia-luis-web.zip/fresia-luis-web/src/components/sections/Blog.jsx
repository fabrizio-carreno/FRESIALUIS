import { useState } from 'react';
import { motion } from 'framer-motion';
import { ArrowUpRight, CalendarDays } from 'lucide-react';
import { posts } from '../../data/content.js';
import { formatPostDate } from '../../lib/dates.js';
import { Stagger, StaggerItem } from '../ui/Reveal.jsx';
import SectionHeading from '../ui/SectionHeading.jsx';
import Modal from '../ui/Modal.jsx';
import DemoBadge from '../ui/DemoBadge.jsx';

export default function Blog() {
  const [post, setPost] = useState(null);
  return (
    <section id="recursos" className="section-y bg-white">
      <div className="container-x">
        <SectionHeading eyebrow="Recursos" title="Blog de psicología y bienestar" text="Artículos y consejos para acompañar tu crecimiento personal." />
        <Stagger className="grid gap-7 md:grid-cols-3">
          {posts.map((p) => (
            <StaggerItem key={p.id}>
              <motion.article whileHover={{ y: -8 }} className="group card h-full overflow-hidden transition-shadow hover:shadow-lift">
                <div className="relative aspect-[4/3] overflow-hidden bg-fucsia-soft">
                  <img src={p.image} alt="" loading="lazy" className="h-full w-full object-cover transition-transform duration-700 group-hover:scale-110" />
                  <span className="absolute left-3 top-3 rounded-full bg-white px-3 py-1 text-xs font-bold text-fucsia">{p.category}</span>
                  {p.demo && <DemoBadge className="absolute bottom-3 left-3">Artículo de ejemplo</DemoBadge>}
                </div>
                <div className="flex flex-col p-6">
                  <p className="flex items-center gap-1.5 text-xs text-marino/50"><CalendarDays size={14} aria-hidden="true" /><time dateTime={p.date}>{formatPostDate(p.date)}</time></p>
                  <h3 className="mt-2 text-xl font-bold leading-snug">{p.title}</h3>
                  <p className="mt-2 text-sm leading-relaxed text-marino/70">{p.excerpt}</p>
                  <button onClick={() => setPost(p)} className="mt-4 inline-flex items-center gap-1 self-start text-sm font-bold text-fucsia hover:underline" aria-label={`Leer más: ${p.title}`}>
                    Leer más <ArrowUpRight size={16} aria-hidden="true" />
                  </button>
                </div>
              </motion.article>
            </StaggerItem>
          ))}
        </Stagger>
      </div>

      <Modal open={Boolean(post)} onClose={() => setPost(null)} label={post?.title || 'Artículo'}>
        {post && (
          <article>
            <img src={post.image} alt="" className="h-56 w-full object-cover sm:h-72" />
            <div className="space-y-4 p-8">
              <p className="text-xs font-bold uppercase tracking-wider text-fucsia">{post.category} · {formatPostDate(post.date)}</p>
              <h3 className="text-3xl font-bold">{post.title}</h3>
              {post.body.map((t, i) => <p key={i} className="leading-relaxed text-marino/80">{t}</p>)}
            </div>
          </article>
        )}
      </Modal>
    </section>
  );
}
