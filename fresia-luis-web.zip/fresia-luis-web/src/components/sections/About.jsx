import { motion } from 'framer-motion';
import { Quote } from 'lucide-react';
import { about, photos } from '../../data/content.js';
import { site } from '../../data/site.js';
import Reveal, { Stagger, StaggerItem } from '../ui/Reveal.jsx';
import SectionHeading from '../ui/SectionHeading.jsx';
import DemoBadge from '../ui/DemoBadge.jsx';
import Icon from '../ui/Icon.jsx';
import Flower from '../ui/Flower.jsx';

export default function About() {
  const facts = about.facts;
  return (
    <section id="sobre-mi" className="section-y relative bg-white">
      <div className="container-x">
        <SectionHeading eyebrow="Sobre mí" title={`Hola, soy ${site.name}`} />

        <div className="grid items-center gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:gap-16">
          <Reveal className="relative mx-auto w-full max-w-md">
            <div aria-hidden="true" className="absolute -inset-4 rotate-3 rounded-[2.5rem] bg-gradient-to-br from-rosa-soft to-sol-soft" />
            <motion.div whileHover={{ rotate: -1.5 }} transition={{ type: 'spring', stiffness: 120 }} className="relative overflow-hidden rounded-[2rem] shadow-lift">
              <img src={photos.withAgenda.src} alt={photos.withAgenda.alt} loading="lazy" width="696" height="860" className="aspect-[4/5] w-full object-cover transition-transform duration-700 hover:scale-105" />
            </motion.div>
            <div className="absolute -bottom-8 -right-6 w-28 sm:w-36"><Flower palette="soft" petals={9} spin /></div>
          </Reveal>

          <div>
            <Reveal>
              <div className="relative rounded-3xl bg-crema p-7 sm:p-9">
                <Quote aria-hidden="true" className="absolute -top-4 left-6 rounded-full bg-fucsia p-2 text-white" size={40} />
                {about.bio.map((p, i) => (
                  <p key={i} className="text-base leading-relaxed text-marino/80 sm:text-lg [&:not(:first-of-type)]:mt-4">{p}</p>
                ))}
                {about.bioIsDemo && <div className="mt-4"><DemoBadge>Texto provisional · edítalo en data/content.js</DemoBadge></div>}
              </div>
            </Reveal>

            {/* Datos profesionales editables: solo aparecen si tienen valor (o como "por completar" en modo demo) */}
            <Stagger className="mt-6 grid gap-4 sm:grid-cols-2">
              {facts.filter((f) => f.value || site.showDemoBadges).map((f) => (
                <StaggerItem key={f.label}>
                  <div className="card h-full p-5">
                    <p className="text-xs font-bold uppercase tracking-wider text-fucsia">{f.label}</p>
                    {f.value ? (
                      <p className="mt-1 text-sm text-marino/80">{f.value}</p>
                    ) : (
                      site.showDemoBadges && <p className="mt-1 text-sm italic text-marino/40">Por completar</p>
                    )}
                  </div>
                </StaggerItem>
              ))}
            </Stagger>
          </div>
        </div>

        {/* Enfoque y filosofía */}
        <div className="mt-20 grid gap-6 md:grid-cols-2">
          <Reveal><div className="card h-full border-t-4 border-fucsia p-8"><h3 className="text-2xl font-bold">Enfoque de trabajo</h3><p className="mt-3 leading-relaxed text-marino/75">{about.approach}</p></div></Reveal>
          <Reveal delay={0.1}><div className="card h-full border-t-4 border-turquesa p-8"><h3 className="text-2xl font-bold">Filosofía profesional</h3><p className="mt-3 leading-relaxed text-marino/75">{about.philosophy}</p></div></Reveal>
        </div>

        <Stagger className="mt-6 grid gap-6 sm:grid-cols-3">
          {about.values.map((v, i) => (
            <StaggerItem key={v.title}>
              <div className="flex h-full items-start gap-4 rounded-3xl bg-crema p-6 transition hover:-translate-y-1 hover:shadow-card">
                <span className={`grid h-12 w-12 shrink-0 place-items-center rounded-2xl text-white ${['bg-fucsia', 'bg-morado', 'bg-turquesa'][i % 3]}`}>
                  <Icon name={v.icon} size={22} />
                </span>
                <div><h3 className="text-lg font-bold">{v.title}</h3><p className="mt-1 text-sm leading-relaxed text-marino/70">{v.text}</p></div>
              </div>
            </StaggerItem>
          ))}
        </Stagger>
      </div>
    </section>
  );
}
