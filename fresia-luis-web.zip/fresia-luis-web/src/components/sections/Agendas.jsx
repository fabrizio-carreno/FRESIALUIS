import { useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { Check, MessageCircle } from 'lucide-react';
import { agendaEditions, agendaFeatured as a } from '../../data/content.js';
import { site } from '../../data/site.js';
import { whatsappLink } from '../../lib/bookingService.js';
import Reveal, { Stagger, StaggerItem } from '../ui/Reveal.jsx';
import SectionHeading from '../ui/SectionHeading.jsx';
import Icon from '../ui/Icon.jsx';
import Button from '../ui/Button.jsx';
import Flower from '../ui/Flower.jsx';

export default function Agendas() {
  const [img, setImg] = useState(0);
  const inquiry = whatsappLink(`Hola Fresia, me gustaría información sobre la ${a.name}.`);

  return (
    <section id="agendas" className="section-y relative overflow-hidden">
      <div aria-hidden="true" className="absolute -right-32 top-20 h-96 w-96 rounded-full bg-morado-soft blur-3xl" />
      <div className="container-x relative">
        <SectionHeading eyebrow="Agendas" title="Volver a mí" text="Un proyecto creativo donde el arte, la psicología y la vida se encuentran en una agenda." />

        {/* Producto destacado, estilo tienda */}
        <div className="grid items-center gap-10 lg:grid-cols-2 lg:gap-16">
          <Reveal className="relative">
            <div className="relative overflow-hidden rounded-[2rem] bg-fucsia-soft shadow-lift">
              <AnimatePresence mode="wait">
                <motion.img key={img} src={a.images[img].src} alt={a.images[img].alt} loading="lazy"
                  initial={{ opacity: 0, scale: 1.05 }} animate={{ opacity: 1, scale: 1 }} exit={{ opacity: 0 }} transition={{ duration: 0.45 }}
                  className="aspect-[4/5] w-full object-cover" />
              </AnimatePresence>
            </div>
            <div className="mt-4 flex gap-3">
              {a.images.map((im, i) => (
                <button key={im.src} onClick={() => setImg(i)} aria-label={`Ver imagen ${i + 1}`} aria-pressed={img === i}
                  className={`h-20 w-16 overflow-hidden rounded-xl border-2 transition ${img === i ? 'border-fucsia' : 'border-transparent opacity-70 hover:opacity-100'}`}>
                  <img src={im.src} alt="" className="h-full w-full object-cover" />
                </button>
              ))}
            </div>
            <div className="absolute -right-6 -top-6 w-24"><Flower palette="soft" petals={8} spin /></div>
          </Reveal>

          <Reveal delay={0.1}>
            <span className="inline-block rounded-full bg-sol px-3 py-1 text-xs font-bold uppercase tracking-wider">Edición 2027</span>
            <h3 className="mt-4 text-4xl font-extrabold leading-tight sm:text-5xl">{a.name}</h3>
            <p className="mt-2 font-script text-2xl text-fucsia">{a.motto}</p>
            <p className="mt-4 text-base leading-relaxed text-marino/75">{a.description}</p>

            <h4 className="mt-7 font-sans text-sm font-bold uppercase tracking-wider text-marino/50">Incluye</h4>
            <ul className="mt-3 grid gap-3">
              {a.includes.map((it) => (
                <li key={it.text} className="flex items-center gap-3 rounded-2xl bg-white p-3 shadow-card">
                  <span className="grid h-10 w-10 place-items-center rounded-xl bg-turquesa-soft text-turquesa-dark"><Icon name={it.icon} size={20} /></span>
                  <span className="font-semibold">{it.text}</span>
                </li>
              ))}
            </ul>

            <ul className="mt-5 space-y-1.5 text-sm text-marino/75">
              {a.benefits.map((b) => <li key={b} className="flex items-start gap-2"><Check size={16} className="mt-0.5 shrink-0 text-turquesa" aria-hidden="true" />{b}</li>)}
            </ul>

            <div className="mt-7 flex flex-wrap items-center gap-4">
              {a.price ? <p className="font-display text-3xl font-bold text-fucsia">{a.price}</p> : <p className="text-sm text-marino/60">{a.priceNote}</p>}
              {inquiry
                ? <Button href={inquiry} target="_blank" rel="noopener noreferrer"><MessageCircle size={18} aria-hidden="true" /> Solicitar información</Button>
                : <Button href="#contacto">Solicitar información</Button>}
            </div>
          </Reveal>
        </div>

        {/* Evolución de las agendas */}
        <div className="mt-24 grid items-center gap-10 rounded-[2.5rem] bg-white p-6 shadow-card sm:p-10 lg:grid-cols-[0.8fr_1.2fr]">
          <Reveal><img src={agendaEditions.image.src} alt={agendaEditions.image.alt} loading="lazy" className="mx-auto max-h-[460px] rounded-2xl object-cover transition-transform duration-500 hover:scale-[1.02]" /></Reveal>
          <div>
            <Reveal>
              <h3 className="text-3xl font-bold sm:text-4xl">{agendaEditions.title}</h3>
              <p className="mt-2 text-marino/70">{agendaEditions.subtitle}</p>
            </Reveal>
            <Stagger className="mt-6 flex flex-wrap gap-3" gap={0.07}>
              {agendaEditions.years.map((y, i) => (
                <StaggerItem key={y}>
                  <span className={`inline-block rounded-full px-5 py-2 font-display text-lg font-bold ${['bg-fucsia text-white', 'bg-turquesa text-white', 'bg-sol', 'bg-morado text-white', 'bg-coral text-white', 'bg-rosa text-white', 'bg-marino text-white'][i % 7]}`}>{y}</span>
                </StaggerItem>
              ))}
            </Stagger>
            <p className="mt-5 text-sm text-marino/55">{agendaEditions.note}</p>
          </div>
        </div>
      </div>
    </section>
  );
}
