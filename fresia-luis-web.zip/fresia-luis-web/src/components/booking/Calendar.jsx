import { useMemo, useState } from 'react';
import { ChevronLeft, ChevronRight } from 'lucide-react';
import { formatMonth, fromISODate, toISODate } from '../../lib/dates.js';

const WEEK = ['L', 'M', 'X', 'J', 'V', 'S', 'D'];
const WEEK_FULL = ['lunes', 'martes', 'miércoles', 'jueves', 'viernes', 'sábado', 'domingo'];

/** Calendario mensual accesible. `isSelectable(date)` decide qué días se pueden elegir. */
export default function Calendar({ value, onChange, isSelectable }) {
  const [cursor, setCursor] = useState(() => {
    const base = value ? fromISODate(value) : new Date();
    return new Date(base.getFullYear(), base.getMonth(), 1);
  });

  const cells = useMemo(() => {
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
    const lead = (first.getDay() + 6) % 7; // lunes = 0
    const days = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0).getDate();
    return [...Array(lead).fill(null), ...Array.from({ length: days }, (_, i) => new Date(cursor.getFullYear(), cursor.getMonth(), i + 1))];
  }, [cursor]);

  const shift = (n) => setCursor((c) => new Date(c.getFullYear(), c.getMonth() + n, 1));

  return (
    <div className="rounded-2xl border border-marino/10 bg-white p-4">
      <div className="mb-3 flex items-center justify-between">
        <button type="button" onClick={() => shift(-1)} aria-label="Mes anterior" className="grid h-9 w-9 place-items-center rounded-full hover:bg-fucsia-soft"><ChevronLeft size={18} aria-hidden="true" /></button>
        <p className="font-display text-lg font-bold capitalize" aria-live="polite">{formatMonth(cursor)}</p>
        <button type="button" onClick={() => shift(1)} aria-label="Mes siguiente" className="grid h-9 w-9 place-items-center rounded-full hover:bg-fucsia-soft"><ChevronRight size={18} aria-hidden="true" /></button>
      </div>
      <div className="grid grid-cols-7 gap-1 text-center text-xs font-bold text-marino/40">
        {WEEK.map((d, i) => <span key={d} title={WEEK_FULL[i]}>{d}</span>)}
      </div>
      <div className="mt-1 grid grid-cols-7 gap-1">
        {cells.map((d, i) => {
          if (!d) return <span key={`e${i}`} />;
          const iso = toISODate(d);
          const ok = isSelectable(d);
          const selected = value === iso;
          return (
            <button
              key={iso} type="button" disabled={!ok} onClick={() => onChange(iso)} aria-pressed={selected}
              aria-label={new Intl.DateTimeFormat('es-PE', { dateStyle: 'full' }).format(d) + (ok ? '' : ' (no disponible)')}
              className={`aspect-square rounded-xl text-sm font-semibold transition ${
                selected ? 'bg-fucsia text-white shadow-lift' : ok ? 'bg-turquesa-soft text-marino hover:bg-turquesa hover:text-white' : 'text-marino/25'
              }`}
            >
              {d.getDate()}
            </button>
          );
        })}
      </div>
    </div>
  );
}
