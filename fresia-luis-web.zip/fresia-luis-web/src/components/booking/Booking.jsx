import { useEffect, useRef, useState } from 'react';
import { AnimatePresence, motion } from 'framer-motion';
import { ArrowLeft, ArrowRight, Check, Clipboard, Loader2, MessageCircle, ShieldCheck } from 'lucide-react';
import { modalityLabels, services } from '../../data/content.js';
import { booking, site } from '../../data/site.js';
import { getSlots, isDateSelectable, usesApi } from '../../lib/availability.js';
import { formatLong } from '../../lib/dates.js';
import { submitRequest } from '../../lib/bookingService.js';
import { validateRequest } from '../../lib/validation.js';
import Button from '../ui/Button.jsx';
import Icon from '../ui/Icon.jsx';
import Calendar from './Calendar.jsx';

const STEPS = ['Servicio', 'Modalidad', 'Fecha y hora', 'Tus datos'];
const emptyForm = { name: '', phone: '', email: '', message: '', consent: false, website: '' };

export default function Booking({ serviceId, onServiceChange }) {
  const [step, setStep] = useState(0);
  const [mode, setMode] = useState(null);
  const [date, setDate] = useState(null);
  const [time, setTime] = useState(null);
  const [form, setForm] = useState(emptyForm);
  const [errors, setErrors] = useState({});
  const [slotsState, setSlotsState] = useState({ status: 'idle', slots: [], source: null });
  const [sending, setSending] = useState(false);
  const [sendError, setSendError] = useState('');
  const [result, setResult] = useState(null);
  const [copied, setCopied] = useState(false);
  const topRef = useRef(null);

  const service = services.find((s) => s.id === serviceId) || null;

  // Si cambia el servicio desde las tarjetas, reinicia lo que depende de él y avanza.
  useEffect(() => {
    if (!serviceId) return;
    setMode(null); setDate(null); setTime(null); setResult(null);
    setStep(1);
  }, [serviceId]);

  // Cargar horarios al elegir fecha
  useEffect(() => {
    if (!date || !service || !mode) return undefined;
    const controller = new AbortController();
    setTime(null);
    setSlotsState({ status: 'loading', slots: [], source: null });
    getSlots({ date, serviceId: service.id, mode, signal: controller.signal })
      .then(({ slots, source }) => setSlotsState({ status: 'ready', slots, source }))
      .catch((e) => e.name !== 'AbortError' && setSlotsState({ status: 'error', slots: [], source: null }));
    return () => controller.abort();
  }, [date, service, mode]);

  const go = (n) => { setStep(n); topRef.current?.scrollIntoView({ behavior: 'smooth', block: 'nearest' }); };
  const set = (k) => (e) => setForm((f) => ({ ...f, [k]: e.target.type === 'checkbox' ? e.target.checked : e.target.value }));

  const canNext = [Boolean(service), Boolean(mode), Boolean(date && time), true][step];

  async function onSubmit(e) {
    e.preventDefault();
    const errs = validateRequest(form);
    setErrors(errs);
    if (Object.keys(errs).length) return;
    setSending(true); setSendError('');
    try {
      const res = await submitRequest(
        { serviceId: service.id, mode, date, time, ...form },
        { serviceName: service.name, modalityLabel: modalityLabels[mode] },
      );
      setResult(res);
      // Importante: no guardamos datos personales en el navegador. Se limpian al enviar.
      setForm(emptyForm);
    } catch (err) {
      setSendError(err.message || 'No pudimos enviar tu solicitud.');
    } finally {
      setSending(false);
    }
  }

  const reset = () => { setResult(null); setStep(0); setMode(null); setDate(null); setTime(null); setErrors({}); onServiceChange(null); };

  const copy = async () => {
    try { await navigator.clipboard.writeText(result.text); setCopied(true); setTimeout(() => setCopied(false), 2500); } catch { /* sin permiso */ }
  };

  /* ───── Pantalla de resultado ───── */
  if (result) {
    const pending = result.status === 'pending';
    return (
      <div id="reservar" ref={topRef} className="card mx-auto max-w-3xl p-6 sm:p-10">
        <div className="text-center">
          <span className="mx-auto grid h-16 w-16 place-items-center rounded-full bg-turquesa-soft text-turquesa-dark"><Check size={30} aria-hidden="true" /></span>
          <h3 className="mt-4 text-3xl font-bold">{pending ? 'Solicitud recibida' : 'Tu solicitud está lista'}</h3>
          <p className="mx-auto mt-3 max-w-lg text-marino/75">
            {pending
              ? 'Registramos tu solicitud. La cita NO está confirmada todavía: Fresia revisará su disponibilidad y te contactará para confirmarla.'
              : 'Aún no se ha enviado. Pulsa el botón para mandarla por WhatsApp. La cita quedará confirmada cuando Fresia te responda.'}
          </p>
          {result.reference && <p className="mt-2 text-sm font-semibold text-fucsia">Referencia: {result.reference}</p>}
        </div>

        <pre className="mt-6 whitespace-pre-wrap rounded-2xl bg-crema p-5 font-sans text-sm leading-relaxed text-marino/80">{result.text}</pre>

        <div className="mt-6 flex flex-col items-center gap-3 sm:flex-row sm:justify-center">
          {result.whatsappUrl ? (
            <Button href={result.whatsappUrl} target="_blank" rel="noopener noreferrer"><MessageCircle size={18} aria-hidden="true" /> {pending ? 'Avisar también por WhatsApp' : 'Enviar por WhatsApp'}</Button>
          ) : (
            <p className="rounded-xl bg-sol-soft p-3 text-center text-sm">Falta configurar el número de WhatsApp (<code>VITE_WHATSAPP_NUMBER</code> o <code>src/data/site.js</code>). Mientras tanto, copia el mensaje.</p>
          )}
          <Button variant="outline" onClick={copy}><Clipboard size={18} aria-hidden="true" /> {copied ? '¡Copiado!' : 'Copiar mensaje'}</Button>
          <Button variant="ghost" onClick={reset}>Nueva solicitud</Button>
        </div>
      </div>
    );
  }

  /* ───── Asistente ───── */
  return (
    <div id="reservar" ref={topRef} className="card mx-auto max-w-4xl overflow-hidden">
      <div className="bg-gradient-to-r from-fucsia to-rosa px-6 py-6 text-white sm:px-10">
        <h3 className="!text-white text-3xl font-bold">Solicita tu cita</h3>
        <p className="mt-1 text-sm text-white/90">
          {usesApi() ? 'Tu solicitud se envía a Fresia y queda pendiente de confirmación.' : 'Prepara tu solicitud y envíala por WhatsApp. Fresia te confirmará la cita.'}
        </p>
        <ol className="mt-5 flex gap-2" aria-label="Progreso">
          {STEPS.map((s, i) => (
            <li key={s} className="flex-1" aria-current={i === step ? 'step' : undefined}>
              <div className={`h-1.5 rounded-full transition-colors ${i <= step ? 'bg-sol' : 'bg-white/30'}`} />
              <span className={`mt-1 hidden text-xs font-semibold sm:block ${i === step ? 'text-white' : 'text-white/60'}`}>{i + 1}. {s}</span>
            </li>
          ))}
        </ol>
      </div>

      <div className="p-6 sm:p-10">
        <AnimatePresence mode="wait">
          <motion.div key={step} initial={{ opacity: 0, x: 24 }} animate={{ opacity: 1, x: 0 }} exit={{ opacity: 0, x: -24 }} transition={{ duration: 0.25 }}>
            {/* 1 · Servicio */}
            {step === 0 && (
              <fieldset>
                <legend className="font-display text-2xl font-bold">¿Qué servicio te interesa?</legend>
                <div className="mt-5 grid gap-3 sm:grid-cols-3">
                  {services.map((s) => (
                    <label key={s.id} className={`cursor-pointer rounded-2xl border-2 p-4 transition ${serviceId === s.id ? 'border-fucsia bg-fucsia-soft' : 'border-marino/10 hover:border-rosa'}`}>
                      <input type="radio" name="service" className="sr-only" checked={serviceId === s.id} onChange={() => onServiceChange(s.id)} />
                      <Icon name={s.icon} size={22} className="text-fucsia" />
                      <p className="mt-2 font-bold">{s.name}</p>
                    </label>
                  ))}
                </div>
              </fieldset>
            )}

            {/* 2 · Modalidad */}
            {step === 1 && service && (
              <fieldset>
                <legend className="font-display text-2xl font-bold">¿Cómo prefieres la sesión?</legend>
                <div className="mt-5 grid gap-3 sm:grid-cols-2">
                  {service.modalities.map((m) => (
                    <label key={m} className={`cursor-pointer rounded-2xl border-2 p-5 transition ${mode === m ? 'border-turquesa bg-turquesa-soft' : 'border-marino/10 hover:border-turquesa'}`}>
                      <input type="radio" name="mode" className="sr-only" checked={mode === m} onChange={() => { setMode(m); setDate(null); setTime(null); }} />
                      <p className="text-lg font-bold">{modalityLabels[m]}</p>
                    </label>
                  ))}
                </div>
              </fieldset>
            )}

            {/* 3 · Fecha y hora */}
            {step === 2 && (
              <div>
                <h4 className="font-display text-2xl font-bold">Elige fecha y horario</h4>
                <div className="mt-5 grid gap-6 md:grid-cols-2">
                  <Calendar value={date} onChange={setDate} isSelectable={(d) => isDateSelectable(d)} />
                  <div aria-live="polite">
                    {!date && <p className="rounded-2xl bg-crema p-5 text-sm text-marino/60">Selecciona un día para ver los horarios.</p>}
                    {date && (
                      <>
                        <p className="font-semibold capitalize">{formatLong(date)}</p>
                        <p className="text-xs text-marino/50">Horarios en {booking.timezoneLabel}</p>
                        {slotsState.status === 'loading' && <p className="mt-4 flex items-center gap-2 text-sm"><Loader2 className="animate-spin" size={16} aria-hidden="true" /> Consultando horarios…</p>}
                        {slotsState.status === 'error' && <p className="mt-4 rounded-xl bg-coral-soft p-3 text-sm">No pudimos consultar los horarios. Inténtalo de nuevo o escríbenos por WhatsApp.</p>}
                        {slotsState.status === 'ready' && slotsState.slots.length === 0 && <p className="mt-4 rounded-xl bg-crema p-3 text-sm">No hay horarios libres ese día. Prueba con otra fecha.</p>}
                        {slotsState.status === 'ready' && slotsState.slots.length > 0 && (
                          <div className="mt-4 grid grid-cols-3 gap-2" role="radiogroup" aria-label="Horarios">
                            {slotsState.slots.map((s) => (
                              <button key={s} type="button" role="radio" aria-checked={time === s} onClick={() => setTime(s)}
                                className={`rounded-xl py-2.5 text-sm font-bold transition ${time === s ? 'bg-fucsia text-white shadow-lift' : 'bg-sol-soft hover:bg-sol'}`}>{s}</button>
                            ))}
                          </div>
                        )}
                        {slotsState.source === 'reference' && (
                          <p className="mt-4 rounded-xl bg-sol-soft p-3 text-xs leading-relaxed">Horarios de referencia: no garantizan disponibilidad. Fresia confirmará tu cita.</p>
                        )}
                      </>
                    )}
                  </div>
                </div>
              </div>
            )}

            {/* 4 · Datos */}
            {step === 3 && (
              <form onSubmit={onSubmit} noValidate>
                <h4 className="font-display text-2xl font-bold">Tus datos de contacto</h4>
                <p className="mt-1 rounded-xl bg-crema p-3 text-sm"><strong>{service?.name}</strong> · {modalityLabels[mode]} · {formatLong(date)} a las {time}</p>

                <div className="mt-5 grid gap-4 sm:grid-cols-2">
                  <Field label="Nombre" error={errors.name}><input className="input" autoComplete="name" value={form.name} onChange={set('name')} aria-invalid={!!errors.name} required /></Field>
                  <Field label="Teléfono / WhatsApp" error={errors.phone}><input className="input" type="tel" inputMode="tel" autoComplete="tel" placeholder="+51 999 999 999" value={form.phone} onChange={set('phone')} aria-invalid={!!errors.phone} required /></Field>
                  <Field label="Correo (opcional)" error={errors.email} className="sm:col-span-2"><input className="input" type="email" autoComplete="email" value={form.email} onChange={set('email')} aria-invalid={!!errors.email} /></Field>
                  <Field label="Mensaje (opcional)" error={errors.message} className="sm:col-span-2">
                    <textarea className="input min-h-24" maxLength={500} value={form.message} onChange={set('message')} aria-invalid={!!errors.message} placeholder="Cuéntanos brevemente lo que necesites." />
                    <span className="mt-1 flex items-start gap-1 text-xs text-marino/55"><ShieldCheck size={14} className="mt-0.5 shrink-0" aria-hidden="true" /> Por tu privacidad, no incluyas información clínica o sensible aquí. Se conversa en la sesión.</span>
                  </Field>

                  {/* Honeypot anti-spam: invisible para personas */}
                  <div aria-hidden="true" className="absolute -left-[9999px] h-0 w-0 overflow-hidden">
                    <label>Sitio web<input tabIndex={-1} autoComplete="off" value={form.website} onChange={set('website')} /></label>
                  </div>

                  <div className="sm:col-span-2">
                    <label className="flex cursor-pointer items-start gap-3 text-sm">
                      <input type="checkbox" className="mt-1 h-5 w-5 accent-fucsia" checked={form.consent} onChange={set('consent')} aria-invalid={!!errors.consent} />
                      <span>Autorizo el uso de mis datos para que me contacten sobre esta solicitud. <a className="font-semibold text-fucsia underline" href={site.legal.privacyUrl}>Política de privacidad</a>.</span>
                    </label>
                    {errors.consent && <p role="alert" className="mt-1 text-xs font-semibold text-coral">{errors.consent}</p>}
                  </div>
                </div>

                {sendError && <p role="alert" className="mt-4 rounded-xl bg-coral-soft p-3 text-sm font-semibold">{sendError}</p>}

                <div className="mt-6 flex flex-wrap items-center justify-between gap-3">
                  <Button variant="ghost" onClick={() => go(2)}><ArrowLeft size={18} aria-hidden="true" /> Atrás</Button>
                  <Button type="submit" disabled={sending}>{sending ? <><Loader2 className="animate-spin" size={18} aria-hidden="true" /> Enviando…</> : usesApi() ? 'Enviar solicitud' : 'Preparar solicitud'}</Button>
                </div>
              </form>
            )}
          </motion.div>
        </AnimatePresence>

        {step < 3 && (
          <div className="mt-8 flex items-center justify-between">
            <Button variant="ghost" onClick={() => go(step - 1)} disabled={step === 0} className={step === 0 ? 'invisible' : ''}><ArrowLeft size={18} aria-hidden="true" /> Atrás</Button>
            <Button onClick={() => go(step + 1)} disabled={!canNext}>Continuar <ArrowRight size={18} aria-hidden="true" /></Button>
          </div>
        )}
      </div>
    </div>
  );
}

function Field({ label, error, children, className = '' }) {
  return (
    <div className={className}>
      <label className="block text-sm font-semibold">
        <span className="mb-1.5 block">{label}</span>
        {children}
      </label>
      {error && <p role="alert" className="mt-1 text-xs font-semibold text-coral">{error}</p>}
    </div>
  );
}
