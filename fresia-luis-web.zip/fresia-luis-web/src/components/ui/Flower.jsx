/**
 * Flor/mandala decorativa en SVG inspirada en la identidad floral de Instagram.
 * Colores de la paleta; `spin` añade rotación lenta (se desactiva con movimiento reducido).
 */
const PALETTES = {
  warm: ['#E90073', '#FF579A', '#FFD83D', '#FF806D'],
  cool: ['#8736B5', '#00B9B5', '#FF579A', '#FFD83D'],
  soft: ['#FF579A', '#FFD83D', '#FF806D', '#8736B5'],
};

export default function Flower({ palette = 'warm', petals = 10, spin = false, className = '' }) {
  const c = PALETTES[palette] || PALETTES.warm;
  const step = 360 / petals;
  return (
    <svg viewBox="-100 -100 200 200" className={`${spin ? 'animate-spinslow' : ''} ${className}`} aria-hidden="true" focusable="false">
      {Array.from({ length: petals }).map((_, i) => (
        <g key={i} transform={`rotate(${i * step})`}>
          <ellipse cx="0" cy="-62" rx="17" ry="34" fill={c[i % 2 === 0 ? 0 : 1]} />
          <ellipse cx="0" cy="-70" rx="5" ry="14" fill={c[2]} opacity=".9" />
        </g>
      ))}
      {Array.from({ length: petals }).map((_, i) => (
        <circle key={`d${i}`} cx="0" cy="-30" r="3.2" fill={c[3]} transform={`rotate(${i * step + step / 2})`} />
      ))}
      <circle r="22" fill={c[2]} />
      <circle r="12" fill="#fff" />
      <circle r="5" fill={c[0]} />
    </svg>
  );
}
