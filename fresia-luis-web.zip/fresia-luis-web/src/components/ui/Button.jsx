import { motion } from 'framer-motion';

const base =
  'group relative inline-flex items-center justify-center gap-2 rounded-full px-6 py-3 text-sm font-semibold transition-colors duration-300 disabled:cursor-not-allowed disabled:opacity-50';

const variants = {
  primary: 'bg-fucsia text-white shadow-lift hover:bg-fucsia-dark',
  secondary: 'bg-turquesa text-white hover:bg-turquesa-dark',
  outline: 'border-2 border-marino/15 bg-white text-marino hover:border-fucsia hover:text-fucsia',
  ghost: 'text-fucsia hover:bg-fucsia-soft',
  dark: 'bg-marino text-white hover:bg-marino-soft',
};

/** Botón/enlace con microinteracción (elevación al hover, leve presión al clic). */
export default function Button({ href, variant = 'primary', className = '', children, ...props }) {
  const Tag = href ? motion.a : motion.button;
  return (
    <Tag
      href={href}
      whileHover={{ y: -2 }}
      whileTap={{ scale: 0.97 }}
      className={`${base} ${variants[variant]} ${className}`}
      {...(!href && { type: props.type || 'button' })}
      {...props}
    >
      {children}
    </Tag>
  );
}
