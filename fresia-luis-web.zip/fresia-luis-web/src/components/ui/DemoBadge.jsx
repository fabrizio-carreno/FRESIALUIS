import { site } from '../../data/site.js';

/** Etiqueta para identificar claramente material provisional. Se oculta con site.showDemoBadges = false. */
export default function DemoBadge({ children = 'Contenido de demostración', className = '' }) {
  if (!site.showDemoBadges) return null;
  return (
    <span
      className={`inline-flex items-center rounded-full bg-sol px-2.5 py-1 text-[10px] font-bold uppercase tracking-wider text-marino ${className}`}
    >
      {children}
    </span>
  );
}
