import {
  Heart, Palette, Sprout, HeartHandshake, Sparkles, Wind, Compass, Users, CloudSun, Flower2, Smile,
  MessageCircleHeart, User, Presentation, BookOpen, CalendarDays, Stamp,
} from 'lucide-react';

// Para usar un icono nuevo: impórtalo arriba y añádelo a este mapa.
const icons = {
  Heart, Palette, Sprout, HeartHandshake, Sparkles, Wind, Compass, Users, CloudSun, Flower2, Smile,
  MessageCircleHeart, User, Presentation, BookOpen, CalendarDays, Stamp,
};

export default function Icon({ name, ...props }) {
  const Cmp = icons[name] || Sparkles;
  return <Cmp aria-hidden="true" {...props} />;
}
