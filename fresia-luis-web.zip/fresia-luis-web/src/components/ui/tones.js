// Clases completas (necesario para que Tailwind las detecte). Se usan como acentos, no como fondos grandes.
export const tones = {
  fucsia:   { soft: 'bg-fucsia-soft',  text: 'text-fucsia',   solid: 'bg-fucsia text-white',    ring: 'ring-fucsia/30' },
  rosa:     { soft: 'bg-rosa-soft',    text: 'text-fucsia',   solid: 'bg-rosa text-white',      ring: 'ring-rosa/30' },
  sol:      { soft: 'bg-sol-soft',     text: 'text-marino',   solid: 'bg-sol text-marino',      ring: 'ring-sol/40' },
  turquesa: { soft: 'bg-turquesa-soft',text: 'text-turquesa-dark', solid: 'bg-turquesa text-white', ring: 'ring-turquesa/30' },
  morado:   { soft: 'bg-morado-soft',  text: 'text-morado',   solid: 'bg-morado text-white',    ring: 'ring-morado/30' },
  coral:    { soft: 'bg-coral-soft',   text: 'text-coral',    solid: 'bg-coral text-white',     ring: 'ring-coral/30' },
};
