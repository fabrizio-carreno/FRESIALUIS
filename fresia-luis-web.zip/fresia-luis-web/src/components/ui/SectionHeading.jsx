import Reveal from './Reveal.jsx';

export default function SectionHeading({ eyebrow, title, text, align = 'center' }) {
  return (
    <Reveal className={`mb-12 max-w-2xl sm:mb-16 ${align === 'center' ? 'mx-auto text-center' : ''}`}>
      {eyebrow && <p className="eyebrow">{eyebrow}</p>}
      <h2 className="mt-1 text-4xl font-bold leading-tight sm:text-5xl">{title}</h2>
      {text && <p className="mt-4 text-base leading-relaxed text-marino/70 sm:text-lg">{text}</p>}
    </Reveal>
  );
}
