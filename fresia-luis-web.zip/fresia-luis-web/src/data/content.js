/**
 * ════════════════════════════════════════════════════════════
 *  CONTENIDO EDITABLE  ·  textos, servicios, agendas, blog
 * ════════════════════════════════════════════════════════════
 * Regla: nada de títulos, certificaciones ni años de experiencia inventados.
 * Los campos en `null` se muestran como "por completar" (solo en modo demo).
 * Los elementos con `demo: true` llevan una etiqueta "Contenido de demostración".
 */

/* ───────────── FOTOS REALES (reemplaza por las originales en alta resolución) ───────────── */
export const photos = {
  hero: { src: '/media/fresia/fresia-retrato.jpg', alt: 'Fresia Luis sonriendo, con blusa blanca bordada con una flor de colores' },
  withAgenda: { src: '/media/fresia/fresia-agenda.jpg', alt: 'Fresia Luis sosteniendo la agenda Volver a mí 2027' },
};

/* ───────────── SOBRE MÍ ───────────── */
export const about = {
  // Biografía: reemplaza estos párrafos por el texto real de Fresia.
  bio: [
    'Soy Fresia Luis, psicóloga. Este espacio nació para acompañarte a volver a ti: conocerte, escucharte y construir tu bienestar a tu propio ritmo.',
    'Aquí encontrarás contenido educativo, herramientas creativas como mis agendas y la posibilidad de solicitar una cita.',
  ],
  bioIsDemo: true, // pon false cuando reemplaces el texto
  // Datos profesionales: complétalos con información verificable. Si es null no se muestra el dato.
  facts: [
    { label: 'Formación académica', value: null },
    { label: 'Experiencia profesional', value: null },
    { label: 'Especialidades', value: null },
    { label: 'Número de colegiatura', value: null },
  ],
  approach:
    'Un enfoque cercano y respetuoso, que pone en el centro tu historia, tus tiempos y tu bienestar emocional.',
  philosophy:
    'Creo que conocerse es un acto de cuidado, y que la creatividad también puede ser una herramienta para sentirnos mejor.',
  values: [
    { icon: 'Heart', title: 'Cercanía', text: 'Un trato humano y cálido en cada conversación.' },
    { icon: 'Palette', title: 'Creatividad', text: 'Arte, color y psicología al servicio de tu proceso.' },
    { icon: 'Sprout', title: 'Crecimiento', text: 'Pequeños pasos que construyen bienestar con el tiempo.' },
  ],
};

/* ───────────── TEMAS DE PSICOLOGÍA ───────────── */
// `tone` define el color de la tarjeta. `icon` es un nombre de lucide-react (ver ui/Icon.jsx).
export const topics = [
  {
    id: 'inteligencia-emocional',
    title: 'Inteligencia emocional',
    icon: 'HeartHandshake',
    tone: 'fucsia',
    short: 'Reconocer lo que sientes y aprender a darle nombre es un buen primer paso.',
    detail: [
      'La inteligencia emocional tiene que ver con identificar, comprender y expresar lo que sentimos, y con reconocer también las emociones de las demás personas.',
      'Ponerle nombre a una emoción suele ayudar a entender qué la despierta y qué necesitas en ese momento.',
    ],
    ideas: ['Pausa y nombra lo que sientes', 'Distingue emoción de reacción', 'Pide lo que necesitas con claridad'],
  },
  {
    id: 'autoestima',
    title: 'Autoestima',
    icon: 'Sparkles',
    tone: 'sol',
    short: 'La forma en que te hablas y te valoras influye en cómo vives.',
    detail: [
      'La autoestima es la valoración que hacemos de nosotras mismas. Se construye con el tiempo, a partir de experiencias, vínculos y diálogo interno.',
      'Observar cómo te hablas y practicar la amabilidad contigo puede ser un buen punto de partida.',
    ],
    ideas: ['Observa tu diálogo interno', 'Reconoce tus logros pequeños', 'Practica la autocompasión'],
  },
  {
    id: 'ansiedad-estres',
    title: 'Ansiedad y manejo del estrés',
    icon: 'Wind',
    tone: 'turquesa',
    short: 'Herramientas generales para cuidar tu calma en el día a día.',
    detail: [
      'Sentir estrés o ansiedad en algunos momentos es una experiencia humana frecuente. Aprender hábitos de cuidado puede ayudarte a transitarlo.',
      'Este contenido es informativo y no reemplaza una evaluación profesional. Si sientes que te sobrepasa, consulta con un profesional de la salud.',
    ],
    ideas: ['Respiración consciente', 'Rutinas de descanso', 'Pedir apoyo cuando lo necesitas'],
  },
  {
    id: 'autoconocimiento',
    title: 'Autoconocimiento',
    icon: 'Compass',
    tone: 'morado',
    short: 'Preguntarte quién eres hoy, qué quieres y qué necesitas.',
    detail: [
      'El autoconocimiento es un camino de exploración continua: tus valores, tus límites, tus gustos y tus formas de relacionarte.',
      'Escribir, dibujar o hacer pausas de reflexión son maneras sencillas de acompañar ese camino.',
    ],
    ideas: ['Escribe preguntas y respuestas', 'Identifica tus valores', 'Revisa tus límites'],
  },
  {
    id: 'relaciones',
    title: 'Relaciones interpersonales',
    icon: 'Users',
    tone: 'coral',
    short: 'Vínculos más sanos empiezan por comunicar y poner límites.',
    detail: [
      'Las relaciones con familia, pareja, amistades o trabajo influyen en nuestro bienestar. La comunicación y el respeto por los límites son claves.',
      'Reflexionar sobre qué esperas y qué ofreces en cada vínculo puede darte claridad.',
    ],
    ideas: ['Comunicación asertiva', 'Escucha activa', 'Límites con cariño'],
  },
  {
    id: 'crecimiento-personal',
    title: 'Crecimiento personal',
    icon: 'Sprout',
    tone: 'turquesa',
    short: 'Avanzar paso a paso, sin presión, hacia lo que te hace bien.',
    detail: [
      'El crecimiento personal no es una carrera: es un proceso con avances, pausas y aprendizajes.',
      'Definir intenciones realistas y celebrar los pasos pequeños ayuda a sostener los cambios.',
    ],
    ideas: ['Define una intención a la vez', 'Celebra tus avances', 'Sé paciente con el proceso'],
  },
  {
    id: 'gestion-emociones',
    title: 'Gestión de emociones',
    icon: 'CloudSun',
    tone: 'rosa',
    short: 'Todas las emociones informan algo; aprender a escucharlas ayuda.',
    detail: [
      'Las emociones no son buenas ni malas: son señales. Gestionarlas no significa eliminarlas, sino aprender a acompañarlas.',
      'Identificar el momento, el cuerpo y el pensamiento que acompañan a una emoción puede darte pistas valiosas.',
    ],
    ideas: ['Registro emocional diario', 'Escucha tu cuerpo', 'Espacios de pausa'],
  },
  {
    id: 'desarrollo-personal',
    title: 'Desarrollo personal',
    icon: 'Flower2',
    tone: 'morado',
    short: 'Hábitos, metas y rutinas que acompañan quien quieres ser.',
    detail: [
      'El desarrollo personal reúne hábitos, metas y aprendizajes que construyes con intención.',
      'Una agenda o un diario pueden ayudarte a darle forma y constancia a ese proceso.',
    ],
    ideas: ['Metas pequeñas y claras', 'Rutinas amables', 'Revisión semanal'],
  },
  {
    id: 'psicologia-bienestar',
    title: 'Psicología y bienestar',
    icon: 'Smile',
    tone: 'sol',
    short: 'Una mirada amplia al bienestar: mente, cuerpo y vínculos.',
    detail: [
      'El bienestar emocional se nutre de muchas áreas: descanso, vínculos, propósito, cuerpo y tiempo para ti.',
      'Conocer estas áreas te permite decidir en cuál quieres poner más atención hoy.',
    ],
    ideas: ['Revisa tus áreas de vida', 'Agenda tiempo para ti', 'Rodéate de apoyo'],
  },
];

export const topicsDisclaimer =
  'Contenido educativo y orientativo. No constituye diagnóstico ni tratamiento, ni promete resultados terapéuticos.';

/* ───────────── SERVICIOS ───────────── */
// Ejemplos editables. `modalities`: 'virtual' | 'presencial'. `duration`/`price`: null = "consultar".
export const services = [
  {
    id: 'orientacion-inicial',
    name: 'Primera conversación',
    icon: 'MessageCircleHeart',
    description: 'Un primer encuentro para conocernos, escuchar lo que te trae y ver cómo puedo acompañarte.',
    modalities: ['virtual', 'presencial'],
    duration: null,
    price: null,
    info: 'Servicio de ejemplo: ajusta nombre, descripción y condiciones.',
    demo: true,
  },
  {
    id: 'sesion-individual',
    name: 'Sesión individual',
    icon: 'User',
    description: 'Un espacio personal y confidencial para trabajar tus temas con tiempo y respeto.',
    modalities: ['virtual', 'presencial'],
    duration: null,
    price: null,
    info: 'Servicio de ejemplo: ajusta nombre, descripción y condiciones.',
    demo: true,
  },
  {
    id: 'taller-charla',
    name: 'Talleres y charlas',
    icon: 'Presentation',
    description: 'Actividades educativas sobre bienestar emocional para grupos, instituciones o comunidades.',
    modalities: ['virtual'],
    duration: null,
    price: null,
    info: 'Servicio de ejemplo: ajusta nombre, descripción y condiciones.',
    demo: true,
  },
];

export const modalityLabels = { virtual: 'Virtual', presencial: 'Presencial' };

/* ───────────── AGENDAS ───────────── */
export const agendaFeatured = {
  id: 'volver-a-mi-2027',
  name: 'Agenda Volver a mí 2027',
  motto: 'Reencontrarme después de perderme en los demás.',
  description:
    'Tu compañera de camino para un año de autoconocimiento, bienestar y conexión contigo.',
  // Visible en la publicación de Instagram. Confirma que sigue vigente antes de mostrarlo.
  price: null, // ej: 'S/ 98'
  priceNote: 'Consulta precio y disponibilidad.',
  includes: [
    { icon: 'BookOpen', text: 'Agenda 2027 (formato A5)' },
    { icon: 'CalendarDays', text: 'Calendario de escritorio 2027' },
    { icon: 'Stamp', text: 'Set de stickers exclusivos' },
  ],
  benefits: [
    'Diseño ilustrado y lleno de color',
    'Pensada para acompañar tu autoconocimiento',
    'Un espacio para organizar tu año con calma',
  ],
  images: [
    { src: '/media/fresia/fresia-agenda.jpg', alt: 'Fresia Luis con la agenda Volver a mí 2027' },
    { src: '/media/agendas/evolucion-agendas.jpg', alt: 'Evolución de las agendas de Fresia, de 2018 a 2024' },
  ],
};

// Ediciones anteriores (según su publicación "La evolución de mis agendas")
export const agendaEditions = {
  title: 'La evolución de mis agendas',
  subtitle: 'Un recorrido creativo de arte, psicología y vida.',
  image: { src: '/media/agendas/evolucion-agendas.jpg', alt: 'Ediciones de las agendas 2018 a 2024' },
  years: ['2018', '2020', '2021', '2022', '2023', '2024', '2027'],
  note: 'Disponibilidad de cada edición: consultar.',
};

/* ───────────── GALERÍA MULTIMEDIA ───────────── */
/**
 * type: 'image' | 'video' | 'embed'
 *  - image: { src }
 *  - video: { src: '/media/videos/archivo.mp4', poster }   (archivo local o URL directa)
 *  - embed: { src: 'https://www.youtube.com/embed/ID' }     (YouTube/Vimeo)
 * Si un video/embed tiene `src: null`, se muestra como demostración.
 */
export const gallery = [
  { id: 'g1', type: 'image', src: '/media/fresia/fresia-retrato.jpg', alt: 'Retrato de Fresia Luis', title: 'Fresia Luis', caption: 'Psicóloga' },
  { id: 'g2', type: 'video', src: null, poster: '/media/fresia/fresia-agenda.jpg', alt: 'Video de presentación', title: 'Video de presentación', caption: 'Conoce a Fresia', demo: true },
  { id: 'g3', type: 'image', src: '/media/fresia/fresia-agenda.jpg', alt: 'Fresia con la agenda Volver a mí', title: 'Agenda Volver a mí', caption: 'Edición 2027' },
  { id: 'g4', type: 'image', src: '/media/gallery/mandala-frase.jpg', alt: 'Ilustración de mandala con una frase sobre el presente', title: 'Frases que acompañan', caption: 'Arte y psicología' },
  { id: 'g5', type: 'video', src: null, poster: '/media/gallery/mandala-frase.jpg', alt: 'Consejo de bienestar emocional', title: 'Consejo de bienestar', caption: 'Videos educativos', demo: true },
  { id: 'g6', type: 'image', src: '/media/agendas/evolucion-agendas.jpg', alt: 'La evolución de las agendas', title: 'La evolución de mis agendas', caption: '2018 – 2024' },
];

/* ───────────── BLOG ───────────── */
// Para publicar: añade un objeto al INICIO de la lista. `body` = lista de párrafos.
export const posts = [
  {
    id: 'ponle-nombre-a-lo-que-sientes',
    category: 'Salud emocional',
    title: 'Ponle nombre a lo que sientes',
    excerpt: 'Un ejercicio sencillo para empezar a escuchar tus emociones con más claridad.',
    date: '2026-11-10',
    image: '/media/gallery/mandala-frase.jpg',
    body: [
      'Nombrar una emoción puede ser el primer paso para comprenderla. Antes de reaccionar, intenta detenerte unos segundos y preguntarte: ¿qué estoy sintiendo ahora?',
      'No hay emociones "correctas" o "incorrectas": todas aportan información sobre lo que necesitas.',
      'Este es un artículo de ejemplo. Reemplázalo por contenido propio.',
    ],
    demo: true,
  },
  {
    id: 'agendas-y-autoconocimiento',
    category: 'Autoconocimiento',
    title: 'Escribir para conocerte: el poder de una agenda',
    excerpt: 'Cómo registrar tus días puede ayudarte a identificar patrones y necesidades.',
    date: '2026-10-28',
    image: '/media/fresia/fresia-agenda.jpg',
    body: [
      'Llevar un registro regular de tus días te permite observar con más calma cómo te sientes y qué cosas te hacen bien.',
      'Puedes empezar con una pregunta diaria: ¿qué necesité hoy?',
      'Este es un artículo de ejemplo. Reemplázalo por contenido propio.',
    ],
    demo: true,
  },
  {
    id: 'limites-con-cariño',
    category: 'Relaciones',
    title: 'Poner límites sin culpa',
    excerpt: 'Ideas para comunicar lo que necesitas cuidando tus vínculos.',
    date: '2026-10-15',
    image: '/media/agendas/evolucion-agendas.jpg',
    body: [
      'Poner límites es una forma de cuidarte y también de cuidar la relación.',
      'Hablar desde lo que necesitas, con claridad y amabilidad, suele facilitar el diálogo.',
      'Este es un artículo de ejemplo. Reemplázalo por contenido propio.',
    ],
    demo: true,
  },
];
