/**
 * ════════════════════════════════════════════════════════════
 *  CONFIGURACIÓN GENERAL DEL SITIO  ·  EDITA AQUÍ
 * ════════════════════════════════════════════════════════════
 * Todo lo que diga `null` o '' es información pendiente de completar.
 * La página muestra avisos discretos en lugar de inventar datos.
 */

const env = import.meta.env;

export const site = {
  name: 'Fresia Luis',
  role: 'Psicóloga',
  tagline: 'Un espacio para volver a ti, conocerte y construir tu bienestar.',
  intro:
    'Psicología, creatividad y herramientas para que te acompañes con calma en tu proceso de crecimiento personal.',

  contact: {
    // Número de WhatsApp: solo dígitos con código de país (Perú = 51). Ej: '51987654321'
    whatsappNumber: env.VITE_WHATSAPP_NUMBER || '',
    email: '', // ej: 'hola@tudominio.com'
    instagramUrl: '', // ej: 'https://www.instagram.com/TU_USUARIO'
    instagramHandle: '', // ej: '@tu_usuario'
    location: '', // ej: 'Lima, Perú'
  },

  legal: {
    privacyUrl: '#', // enlace a tu política de privacidad
    termsUrl: '#', // enlace a términos y condiciones
  },

  // ¿Mostrar avisos de "Contenido de demostración" sobre material provisional?
  showDemoBadges: true,
};

/** Navegación principal (id = id de la sección) */
export const nav = [
  { id: 'inicio', label: 'Inicio' },
  { id: 'sobre-mi', label: 'Sobre mí' },
  { id: 'psicologia', label: 'Psicología' },
  { id: 'servicios', label: 'Servicios' },
  { id: 'recursos', label: 'Recursos' },
  { id: 'agendas', label: 'Agendas' },
  { id: 'contacto', label: 'Contacto' },
];

/**
 * ════════════════════════════════════════════════════════════
 *  RESERVAS  ·  ver docs/BOOKING_API.md
 * ════════════════════════════════════════════════════════════
 * provider:
 *   'whatsapp' → la solicitud se envía por WhatsApp (funciona sin backend).
 *   'api'      → se envía a tu backend/servicio de reservas (apiUrl).
 */
export const booking = {
  provider: env.VITE_BOOKING_PROVIDER || 'whatsapp',
  apiUrl: env.VITE_BOOKING_API_URL || '',
  timezoneLabel: 'hora de Lima, GMT-5',
  slotMinutes: 50,
  minNoticeHours: 24, // anticipación mínima
  maxDaysAhead: 45, // hasta cuántos días adelante se puede solicitar
  blockedDates: [], // feriados / vacaciones: ['2026-12-25']

  /**
   * HORARIOS DE REFERENCIA (provisionales).
   * Solo se usan cuando provider = 'whatsapp' o si la API no responde.
   * 0 = domingo … 6 = sábado. Reemplázalos por el horario real de Fresia.
   */
  weeklySchedule: {
    1: [['09:00', '12:00'], ['15:00', '18:00']],
    2: [['09:00', '12:00'], ['15:00', '18:00']],
    3: [['09:00', '12:00'], ['15:00', '18:00']],
    4: [['09:00', '12:00'], ['15:00', '18:00']],
    5: [['09:00', '12:00']],
  },
};
