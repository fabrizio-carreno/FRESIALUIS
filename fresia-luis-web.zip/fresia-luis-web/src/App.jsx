import Header from './components/layout/Header.jsx';
import Footer from './components/layout/Footer.jsx';
import ScrollProgress from './components/layout/ScrollProgress.jsx';
import FloatingWhatsApp from './components/layout/FloatingWhatsApp.jsx';
import Hero from './components/sections/Hero.jsx';
import About from './components/sections/About.jsx';
import Topics from './components/sections/Topics.jsx';
import MediaGallery from './components/sections/MediaGallery.jsx';
import Services from './components/sections/Services.jsx';
import Agendas from './components/sections/Agendas.jsx';
import Blog from './components/sections/Blog.jsx';

export default function App() {
  return (
    <>
      <a href="#contenido" className="sr-only focus:not-sr-only focus:fixed focus:left-4 focus:top-4 focus:z-[200] focus:rounded-full focus:bg-fucsia focus:px-5 focus:py-3 focus:text-white">
        Saltar al contenido
      </a>
      <ScrollProgress />
      <Header />
      <main id="contenido">
        <Hero />
        <About />
        <Topics />
        <MediaGallery />
        <Services />
        <Agendas />
        <Blog />
      </main>
      <Footer />
      <FloatingWhatsApp />
    </>
  );
}
