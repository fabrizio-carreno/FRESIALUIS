# Contrato de la API de reservas

La web funciona de dos formas (se elige con `VITE_BOOKING_PROVIDER`):

| Proveedor | Qué hace | Requiere backend |
|-----------|----------|------------------|
| `whatsapp` (por defecto) | Arma la solicitud y abre WhatsApp con el mensaje ya escrito. Horarios = referencia de `src/data/site.js`. | No |
| `api` | Consulta disponibilidad y envía la solicitud a tu servidor. | Sí |

**Regla de la interfaz:** la web nunca muestra "cita confirmada". Solo "solicitud recibida / lista", pendiente de confirmación de Fresia.

## Activar el modo `api`
1. En `.env`: `VITE_BOOKING_PROVIDER=api` y `VITE_BOOKING_API_URL=https://tu-api.com/api` (en desarrollo: `/api`).
2. Implementa estos dos endpoints (o adapta `server-example/server.mjs`).

### `GET {API_URL}/availability?date=YYYY-MM-DD&service=<id>&mode=<virtual|presencial>`
```json
{ "date": "2026-12-01", "slots": ["09:00", "09:50", "15:00"] }
```
Horas locales (hora de Lima). Lista vacía = sin cupos.

### `POST {API_URL}/appointment-requests`
Cuerpo JSON:
```json
{
  "serviceId": "sesion-individual", "mode": "virtual",
  "date": "2026-12-01", "time": "09:00",
  "name": "…", "phone": "+51…", "email": "…|null", "message": "…|null",
  "consent": true, "website": ""
}
```
Respuestas: `201 { "reference": "FL-XXXX", "status": "pending" }` · `409` horario ocupado · `422 { "error" }` datos inválidos · `429` demasiadas solicitudes.
`website` es un campo trampa anti-spam: si llega con texto, ignora la solicitud.

## Alternativas a un backend propio
Conecta Calendly, Cal.com o Google Calendar añadiendo un proveedor en `src/lib/bookingService.js` (objeto `providers`) y, si aplica, adaptando `getSlots` en `src/lib/availability.js`.

## Privacidad y seguridad (antes de producción)
- Los datos de contacto se envían por HTTPS y **no se guardan en el navegador**.
- No almacenes información clínica. El formulario pide no incluirla.
- Guarda las solicitudes en una base de datos con acceso restringido y cifrado, define cuánto tiempo se conservan y publica tu política de privacidad (`site.legal.privacyUrl`).
- Restringe CORS a tu dominio, mantén el límite de peticiones y valida siempre en el servidor.
- Revisa la normativa de protección de datos personales aplicable (en Perú, la Ley 29733).
