// ════════════════════════════════════════════════════════════
//  SERVIDOR DE EJEMPLO para el sistema de citas (sin dependencias)
//  Ejecuta:  npm run api   →  http://localhost:8787
//
//  ⚠️  ES UNA BASE DE PRUEBAS, NO PRODUCCIÓN.
//  - Guarda las solicitudes solo en memoria (se pierden al reiniciar).
//  - No guarda ni registra datos personales: solo un código de referencia.
//  Para producción: reemplaza `store` por una base de datos segura (cifrado, accesos
//  restringidos, política de retención), añade notificación a Fresia y un panel/flujo
//  para confirmar o rechazar solicitudes. Ver docs/BOOKING_API.md.
// ════════════════════════════════════════════════════════════
import http from 'node:http';
import { randomUUID } from 'node:crypto';

const PORT = Number(process.env.PORT || 8787);
const ALLOWED_ORIGIN = process.env.ALLOWED_ORIGIN || 'http://localhost:5173';
const SLOT_MIN = 50;
const MIN_NOTICE_H = 24;
const MAX_BODY = 10_000;

// Horario semanal de referencia (0=domingo). Igual que src/data/site.js; edítalo para tu caso.
const SCHEDULE = { 1: [['09:00', '12:00'], ['15:00', '18:00']], 2: [['09:00', '12:00'], ['15:00', '18:00']], 3: [['09:00', '12:00'], ['15:00', '18:00']], 4: [['09:00', '12:00'], ['15:00', '18:00']], 5: [['09:00', '12:00']] };
const SERVICES = ['orientacion-inicial', 'sesion-individual', 'taller-charla'];
const MODES = ['virtual', 'presencial'];

/** Solicitudes pendientes (en memoria). Cada una retiene su horario hasta que Fresia la resuelva. */
const store = new Map(); // reference -> { date, time, status }

const toMin = (t) => { const [h, m] = t.split(':').map(Number); return h * 60 + m; };
const fromMin = (n) => `${String(Math.floor(n / 60)).padStart(2, '0')}:${String(n % 60).padStart(2, '0')}`;
const isDate = (s) => /^\d{4}-\d{2}-\d{2}$/.test(s) && !Number.isNaN(Date.parse(`${s}T00:00:00`));

function slotsFor(dateStr) {
  const [y, m, d] = dateStr.split('-').map(Number);
  const day = new Date(y, m - 1, d);
  const taken = new Set([...store.values()].filter((r) => r.date === dateStr && r.status !== 'rejected').map((r) => r.time));
  const out = [];
  for (const [from, to] of SCHEDULE[day.getDay()] || []) {
    for (let t = toMin(from); t + SLOT_MIN <= toMin(to); t += SLOT_MIN) {
      const start = new Date(y, m - 1, d, 0, t);
      if (start - Date.now() >= MIN_NOTICE_H * 3600e3 && !taken.has(fromMin(t))) out.push(fromMin(t));
    }
  }
  return out;
}

// Límite simple de peticiones por IP (5 solicitudes / 10 min)
const hits = new Map();
function rateLimited(ip) {
  const now = Date.now();
  const list = (hits.get(ip) || []).filter((t) => now - t < 600_000);
  list.push(now); hits.set(ip, list);
  return list.length > 5;
}

function send(res, status, body) {
  res.writeHead(status, {
    'Content-Type': 'application/json; charset=utf-8',
    'Access-Control-Allow-Origin': ALLOWED_ORIGIN,
    'Access-Control-Allow-Methods': 'GET,POST,OPTIONS',
    'Access-Control-Allow-Headers': 'Content-Type',
    'X-Content-Type-Options': 'nosniff',
  });
  res.end(JSON.stringify(body));
}

const readBody = (req) => new Promise((resolve, reject) => {
  let size = 0; const chunks = [];
  req.on('data', (c) => { size += c.length; if (size > MAX_BODY) { reject(new Error('too_large')); req.destroy(); } else chunks.push(c); });
  req.on('end', () => resolve(Buffer.concat(chunks).toString('utf8')));
  req.on('error', reject);
});

function validate(b) {
  if (!SERVICES.includes(b.serviceId)) return 'Servicio inválido.';
  if (!MODES.includes(b.mode)) return 'Modalidad inválida.';
  if (!isDate(b.date) || !/^\d{2}:\d{2}$/.test(b.time || '')) return 'Fecha u hora inválida.';
  if (typeof b.name !== 'string' || b.name.trim().length < 2 || b.name.length > 100) return 'Nombre inválido.';
  if (!/^\+?\d{7,15}$/.test(String(b.phone || '').replace(/[\s()-]/g, ''))) return 'Teléfono inválido.';
  if (b.email && !/^[^\s@]+@[^\s@]+\.[^\s@]{2,}$/.test(b.email)) return 'Correo inválido.';
  if (b.message && String(b.message).length > 500) return 'Mensaje demasiado largo.';
  if (b.consent !== true) return 'Falta el consentimiento.';
  return null;
}

http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host}`);
  if (req.method === 'OPTIONS') return send(res, 204, {});

  // GET /api/availability?date=YYYY-MM-DD&service=&mode=
  if (req.method === 'GET' && url.pathname === '/api/availability') {
    const date = url.searchParams.get('date');
    if (!isDate(date || '')) return send(res, 400, { error: 'Fecha inválida.' });
    return send(res, 200, { date, slots: slotsFor(date) });
  }

  // POST /api/appointment-requests
  if (req.method === 'POST' && url.pathname === '/api/appointment-requests') {
    if (rateLimited(req.socket.remoteAddress || 'x')) return send(res, 429, { error: 'Demasiadas solicitudes. Inténtalo más tarde.' });
    let body;
    try { body = JSON.parse(await readBody(req)); } catch { return send(res, 400, { error: 'Solicitud inválida.' }); }
    if (body.website) return send(res, 201, { reference: 'OK', status: 'pending' }); // honeypot: simula éxito a bots
    const problem = validate(body);
    if (problem) return send(res, 422, { error: problem });
    if (!slotsFor(body.date).includes(body.time)) return send(res, 409, { error: 'Horario no disponible.' });

    const reference = `FL-${randomUUID().slice(0, 8).toUpperCase()}`;
    store.set(reference, { date: body.date, time: body.time, status: 'pending' });
    // TODO producción: guardar de forma segura + avisar a Fresia (correo/WhatsApp Business API) con los datos de contacto.
    console.log(`[solicitud] ${reference} ${body.date} ${body.time} (sin datos personales en el log)`);
    return send(res, 201, { reference, status: 'pending' });
  }

  send(res, 404, { error: 'No encontrado.' });
}).listen(PORT, () => console.log(`API de ejemplo en http://localhost:${PORT}  (origen permitido: ${ALLOWED_ORIGIN})`));
