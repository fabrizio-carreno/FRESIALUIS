# Fresia Luis · Sitio web de psicología y bienestar

React + Vite + Tailwind CSS + Framer Motion + Lucide.

## Ejecutar
```bash
npm install
cp .env.example .env     # y completa el número de WhatsApp
npm run dev              # http://localhost:5173
npm run build            # genera /dist para publicar
```
Probar el sistema de citas con backend de ejemplo: en `.env` pon `VITE_BOOKING_PROVIDER=api` y `VITE_BOOKING_API_URL=/api`, y en otra terminal `npm run api`.

## Arquitectura
```
src/
  data/site.js          ← contacto, navegación, configuración de reservas y horarios
  data/content.js       ← TODOS los textos: sobre mí, temas, servicios, agendas, galería, blog
  components/
    layout/             Header, Footer, ScrollProgress, FloatingWhatsApp
    sections/           Hero, About, Topics, MediaGallery, Services, Agendas, Blog
    booking/            Booking (asistente de 4 pasos) y Calendar
    ui/                 Button, Reveal (animaciones), Modal, Flower, DemoBadge…
  lib/                  availability, bookingService, validation, dates (lógica sin UI)
server-example/         API de ejemplo sin dependencias (solo pruebas)
docs/BOOKING_API.md     contrato de integración de reservas
```

## Qué editar
| Quiero cambiar… | Archivo |
|---|---|
| Fotos de Fresia | Reemplaza `public/media/fresia/*.jpg` (mismos nombres) o cambia rutas en `content.js` → `photos` |
| Videos | Pon los `.mp4` en `public/media/videos/` y completa `src` en `content.js` → `gallery` (también acepta YouTube/Vimeo con `type: 'embed'`) |
| Biografía, formación, experiencia, especialidades | `content.js` → `about` (lo que esté en `null` no se muestra como dato) |
| Temas de psicología | `content.js` → `topics` |
| Servicios y modalidades | `content.js` → `services` |
| Agenda, ediciones, precio | `content.js` → `agendaFeatured`, `agendaEditions` |
| Artículos del blog | `content.js` → `posts` (añade uno al inicio) |
| WhatsApp, correo, Instagram, ubicación | `.env` y `data/site.js` → `contact` |
| Horarios, anticipación, feriados | `data/site.js` → `booking` |
| Quitar etiquetas "Contenido de demostración" | `data/site.js` → `showDemoBadges: false` |
| Colores / tipografías | `tailwind.config.js` e `index.html` |

## Notas importantes
- **Fotos provisionales:** las dos fotos de Fresia y las piezas de agendas se recortaron de una captura de Instagram (baja resolución). Reemplázalas por los originales para una nitidez premium.
- **Citas:** el sitio nunca muestra "cita confirmada"; solo "solicitud", pendiente de que Fresia confirme. Ver `docs/BOOKING_API.md`.
- **Pendiente de confirmar:** el precio de la agenda aparece en su publicación; está en `null` hasta que decidas mostrarlo.
- **Privacidad:** no se guardan datos en el navegador ni se piden datos clínicos. Antes de recibir datos reales, configura un backend seguro y publica la política de privacidad.
- **Accesibilidad/SEO:** navegación por teclado, modales con foco controlado, `prefers-reduced-motion`, metadatos y Open Graph. Actualiza título, descripción y dominio en `index.html`.
