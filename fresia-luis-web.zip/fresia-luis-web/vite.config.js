import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';

export default defineConfig({
  plugins: [react()],
  server: {
    port: 5173,
    // En desarrollo, /api se redirige al servidor de ejemplo (npm run api).
    proxy: { '/api': 'http://localhost:8787' },
  },
});
