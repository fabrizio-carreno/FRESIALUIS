/** @type {import('tailwindcss').Config} */
export default {
  content: ['./index.html', './src/**/*.{js,jsx}'],
  theme: {
    extend: {
      colors: {
        fucsia: { DEFAULT: '#E90073', dark: '#C20061', soft: '#FDE3EF' },
        rosa: { DEFAULT: '#FF579A', soft: '#FFE1EC' },
        sol: { DEFAULT: '#FFD83D', soft: '#FFF2B8' },
        turquesa: { DEFAULT: '#00B9B5', dark: '#008F8C', soft: '#D5F5F4' },
        morado: { DEFAULT: '#8736B5', soft: '#EBDDF4' },
        marino: { DEFAULT: '#14264B', soft: '#3A4A6B' },
        coral: { DEFAULT: '#FF806D', soft: '#FFE3DE' },
        crema: { DEFAULT: '#FFF6ED', dark: '#FBE9D8' },
      },
      fontFamily: {
        display: ['Fraunces', 'Georgia', 'serif'],
        sans: ['"Plus Jakarta Sans"', 'system-ui', 'sans-serif'],
        script: ['Caveat', 'cursive'],
      },
      boxShadow: {
        card: '0 1px 2px rgba(20,38,75,.04), 0 8px 24px -8px rgba(20,38,75,.10)',
        lift: '0 2px 4px rgba(20,38,75,.04), 0 24px 48px -16px rgba(233,0,115,.28)',
      },
      keyframes: {
        floaty: { '0%,100%': { transform: 'translateY(0)' }, '50%': { transform: 'translateY(-10px)' } },
        spinslow: { to: { transform: 'rotate(360deg)' } },
        blob: {
          '0%,100%': { borderRadius: '60% 40% 55% 45% / 55% 45% 55% 45%' },
          '50%': { borderRadius: '45% 55% 40% 60% / 45% 60% 40% 55%' },
        },
      },
      animation: {
        floaty: 'floaty 7s ease-in-out infinite',
        spinslow: 'spinslow 60s linear infinite',
        blob: 'blob 14s ease-in-out infinite',
      },
    },
  },
  plugins: [],
};
